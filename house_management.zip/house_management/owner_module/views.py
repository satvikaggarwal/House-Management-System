# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect

from owner_module.models import Owner, House

# Create your views here.

def register(request):
    if request.method == "POST":
        # Capture data submitted by user on registration form
        owner_name = request.POST.get("owner_name")
        owner_email = request.POST.get("owner_email")
        owner_password = request.POST.get("owner_password")

        # Save data to database
        obj = Owner(owner_name=owner_name, owner_email=owner_email, owner_password=owner_password)
        obj.save()

        # return HTML Page
        return render(request, 'owner_module/register.html', {"message": "User Registration Completed!"})

    return render(request, 'owner_module/register.html')


def login(request):
    if request.method == "POST":
        # Capture data submitted by user on registration form
        owner_email = request.POST.get("owner_email")
        owner_password = request.POST.get("owner_password")

        owners = Owner.objects.filter(owner_email=owner_email, owner_password=owner_password)
        if owners:
            # owner provided correct email and password
            request.session['owner_name'] = owners[0].owner_name
            request.session['owner_email'] = owners[0].owner_email
            request.session['owner_id'] = owners[0].pk
            return HttpResponseRedirect("/owner/home")
        else:
            # Wrong username and/or password
            return render(request, 'owner_module/login.html', {"message": "Login failed!"})

    return render(request, 'owner_module/login.html')


def logout(request):
    del request.session['owner_name']
    del request.session['owner_email']
    del request.session['owner_id']
    return HttpResponseRedirect("/owner/login")


def home(request):
    # Get Current owner who is logged in
    owner = Owner.objects.get(pk=request.session['owner_id'])

    # Get all houses created by the owner
    houses = House.objects.filter(owner=owner)

    return render(request, 'owner_module/home.html', {"houses": houses})

def add_house(request):
    # Get Current owner who is logged in
    owner = Owner.objects.get(pk=request.session['owner_id'])

    if request.method == "POST":
        # Capture data submitted by user on registration form
        name = request.POST.get("name")
        bhk = request.POST.get("bhk")
        size = request.POST.get("size")
        location = request.POST.get("location")
        price = request.POST.get("price", "0")

        house = House(name=name, bhk=bhk, size=size, location=location, price=int(price), owner=owner)
        house.save()
        return HttpResponseRedirect("/owner/home")

    return render(request, 'owner_module/add_house.html')

def update_house(request, house_id):
    owner = Owner.objects.get(pk=request.session['owner_id'])
    house = House.objects.get(pk=house_id)

    if request.method == "POST":
        name = request.POST.get("name")
        bhk = request.POST.get("bhk")
        size = request.POST.get("size")
        location = request.POST.get("location")
        price = request.POST.get("price")

        house.name = name
        house.bhk = bhk
        house.size = size
        house.location = location
        house.price = price
        house.save()

        return HttpResponseRedirect("/owner/home")

    return render(request, 'owner_module/update_house.html', {"house": house})

def delete_house(request, house_id):
    # Get house with primary Key
    house = House.objects.get(pk=house_id)

    # Delete House from database
    house.delete()

    # Return user to Home List Page
    return HttpResponseRedirect("/owner/home")