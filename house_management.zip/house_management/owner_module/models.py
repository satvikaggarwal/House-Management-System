# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.

class Owner(models.Model):
    owner_name = models.CharField(max_length=255, verbose_name="Owner Name")
    owner_email = models.CharField(max_length=255, verbose_name="Owner Email")
    owner_password = models.CharField(max_length=255, verbose_name="Owner Password")

class House(models.Model):
    owner = models.ForeignKey(Owner, on_delete=models.CASCADE)
    name = models.CharField(max_length=255, verbose_name="House Name")
    bhk = models.CharField(max_length=255, verbose_name="BHK")
    size = models.CharField(max_length=255, verbose_name="Size in sq. yds.")
    location = models.CharField(max_length=255, verbose_name="Location")
    price = models.IntegerField(verbose_name="Price in Rupees")