from django.conf.urls import url
from owner_module import views

urlpatterns = [
    url(r'^registration$', views.register, name="register"),
    url(r'^login$', views.login, name="login"),
    url(r'^logout$', views.logout, name="logout"),
    url(r'^home$', views.home, name="home"),
    url(r'^add_house$', views.add_house, name="add_house"),
    url(r'^update_house/(?P<house_id>\d+)$', views.update_house, name="update_house"),
    url(r'^delete_house/(?P<house_id>\d+)$', views.delete_house, name="delete_house"),
]

app_name='owner'