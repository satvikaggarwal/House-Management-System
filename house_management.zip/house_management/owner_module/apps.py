from django.apps import AppConfig


class OwnerModuleConfig(AppConfig):
    name = 'owner_module'
