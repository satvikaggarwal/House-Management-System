# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from customer_module.models import *

# Register your models here.
admin.site.register(Customer)