from django.conf.urls import url

from customer_module import views

urlpatterns = [
    url(r'^registration$', views.register, name="register"),
    url(r'^login$', views.login, name="login"),
    url(r'^logout$', views.logout, name="logout"),
    url(r'^home$', views.home, name="home"),
    url(r'^update$', views.update_details, name="update"),
]

app_name="customer"