# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Customer(models.Model):
    customer_name = models.CharField(max_length=255, verbose_name="Customer Name")
    customer_email = models.CharField(max_length=255, verbose_name="Customer Email")
    customer_password = models.CharField(max_length=255, verbose_name="Customer Password")
    customer_phone = models.CharField(max_length=255, verbose_name="Customer Phone")
    customer_title = models.CharField(max_length=255, verbose_name="Customer Title")