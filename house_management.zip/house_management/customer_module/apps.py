from django.apps import AppConfig


class CustomerModuleConfig(AppConfig):
    name = 'customer_module'
