# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponseRedirect

from customer_module.models import Customer
from owner_module import models as owner_models

# Create your views here.

def register(request):
    if request.method == "POST":
        # Capture data submitted by user on registration form
        customer_name = request.POST.get("customer_name")
        customer_email = request.POST.get("customer_email")
        customer_password = request.POST.get("customer_password")
        customer_phone = request.POST.get("customer_phone")
        customer_title = request.POST.get("customer_title")

        # Save data to database
        obj = Customer(
            customer_name=customer_name, 
            customer_email=customer_email, 
            customer_password=customer_password,
            customer_phone=customer_phone,
            customer_title=customer_title
        )
        obj.save()

        # return HTML Page
        return render(request, 'customer_module/register.html', {"message": "User Registration Completed!"})

    return render(request, 'customer_module/register.html')


def login(request):
    if request.method == "POST":
        # Capture data submitted by user on registration form
        customer_email = request.POST.get("customer_email")
        customer_password = request.POST.get("customer_password")

        customers = Customer.objects.filter(customer_email=customer_email, customer_password=customer_password)
        if customers:
            # customer provided correct email and password
            request.session['customer_name'] = customers[0].customer_name
            request.session['customer_email'] = customers[0].customer_email
            request.session['customer_title'] = customers[0].customer_title
            request.session['customer_id'] = customers[0].pk
            return HttpResponseRedirect("/customer/home")
        else:
            # Wrong username and/or password
            return render(request, 'customer_module/login.html', {"message": "Login failed!"})

    return render(request, 'customer_module/login.html')


def logout(request):
    del request.session['customer_name']
    del request.session['customer_email']
    del request.session['customer_id']
    return HttpResponseRedirect("/customer/login")

def home(request):
    customer = Customer.objects.get(pk=request.session['customer_id'])
    houses = owner_models.House.objects.all().order_by('owner')

    if request.method == "POST":
        min_price = request.POST.get("min_price", "")
        max_price = request.POST.get("max_price", "")

        if min_price == "" and max_price == "":
            return render(request, 'customer_module/home.html', {"houses": houses, "message": "Min. Price and Max. Price both cannot be blank."})

        if min_price and max_price and int(min_price) > int(max_price):
            return render(request, 'customer_module/home.html', {"houses": houses, "message": "Min. Price cannot be more than Max. Price."})

        if min_price:
            houses = houses.filter(price__gte=int(min_price))
        if max_price:
            houses = houses.filter(price__lte=int(max_price))

        return render(request, 'customer_module/home.html', {"houses": houses, "min_price": min_price, "max_price": max_price})
        
    return render(request, 'customer_module/home.html', {"houses": houses})

def update_details(request):
    customer = Customer.objects.get(pk=request.session['customer_id'])

    if request.method == "POST":
        customer_name = request.POST.get("customer_name")
        customer_email = request.POST.get("customer_email")
        customer_password = request.POST.get("customer_password")
        customer_phone = request.POST.get("customer_phone")
        customer_title = request.POST.get("customer_title")

        # Save data to database
        customer.customer_name=customer_name
        customer.customer_email=customer_email
        customer.customer_password=customer_password
        customer.customer_phone=customer_phone
        customer.customer_title=customer_title
        customer.save()

        request.session['customer_name'] = customer_name
        request.session['customer_email'] = customer_email
        request.session['customer_title'] = customer_title
    
    return render(request, 'customer_module/update.html', {"customer": customer})