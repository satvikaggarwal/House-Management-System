# -*- coding: utf-8 -*-
from django.db import models

# Create your models here.

class Admin(models.Model):
    admin_name = models.CharField(max_length=255, verbose_name="Admin Name")
    admin_email = models.CharField(max_length=255, verbose_name="Admin Email")
    admin_password = models.CharField(max_length=255, verbose_name="Admin Password")

app_name='admin'