from django.conf.urls import url
from admin_module import views

urlpatterns = [
    url(r'^registration$', views.register, name="register"),
    url(r'^login$', views.login, name="login"),
    url(r'^logout$', views.logout, name="logout"),
    url(r'^home$', views.home, name="home"),

    url(r'^customers/view$', views.customers_view, name="customers_view"),
    url(r'^customers/update/(?P<customerid>\d+)$', views.customers_update, name="customers_update"),
    url(r'^customers/add$', views.customers_add, name="customers_add"),
]

app_name="admin"