# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse

from admin_module.models import Admin
from owner_module import models as owner_models
from customer_module import models as customer_models

# Create your views here.

def register(request):
    if request.method == "POST":
        # Capture data submitted by user on registration form
        admin_name = request.POST.get("admin_name")
        admin_email = request.POST.get("admin_email")
        admin_password = request.POST.get("admin_password")

        # Save data to database
        obj = Admin(admin_name=admin_name, admin_email=admin_email, admin_password=admin_password)
        obj.save()

        # return HTML Page
        return render(request, 'admin_module/register.html', {"message": "User Registration Completed!"})

    return render(request, 'admin_module/register.html')


def login(request):
    if request.method == "POST":
        # Capture data submitted by user on registration form
        admin_email = request.POST.get("admin_email")
        admin_password = request.POST.get("admin_password")

        admins = Admin.objects.filter(admin_email=admin_email, admin_password=admin_password)
        if admins:
            # admin provided correct email and password
            request.session['admin_name'] = admins[0].admin_name
            request.session['admin_email'] = admins[0].admin_email
            request.session['admin_id'] = admins[0].pk
            return HttpResponseRedirect("/admin/home")
        else:
            # Wrong username and/or password
            return render(request, 'admin_module/login.html', {"message": "Login failed!"})

    return render(request, 'admin_module/login.html')


def logout(request):
    del request.session['admin_name']
    del request.session['admin_email']
    del request.session['admin_id']
    return HttpResponseRedirect("/admin/login")


def home(request):
    owners = owner_models.Owner.objects.all()
    houses = owner_models.House.objects.all()
    data = {}
    for i in owners:
        data[i] = houses.filter(owner=i)
    return render(request, "admin_module/home.html", {"data": data})


def index(request):
    return render(request, "admin_module/index.html")


def customers_view(request):
    customers = customer_models.Customer.objects.all()
    return render(request, "admin_module/customers_view.html", {"customers": customers})


def customers_update(request, customerid):
    customer = customer_models.Customer.objects.get(pk=customerid)

    if request.method == "POST":
        customer_name = request.POST.get("customer_name")
        customer_email = request.POST.get("customer_email")
        customer_password = request.POST.get("customer_password")
        customer_phone = request.POST.get("customer_phone")
        customer_title = request.POST.get("customer_title")

        # Save data to database
        customer.customer_name=customer_name
        customer.customer_email=customer_email
        customer.customer_password=customer_password
        customer.customer_phone=customer_phone
        customer.customer_title=customer_title
        customer.save()

        return HttpResponseRedirect("/admin/customers/view")
    
    return render(request, 'admin_module/customers_update.html', {"customer": customer})

def customers_add(request):
    if request.method == "POST":
        # Capture data submitted by user on registration form
        customer_name = request.POST.get("customer_name")
        customer_email = request.POST.get("customer_email")
        customer_password = request.POST.get("customer_password")
        customer_phone = request.POST.get("customer_phone")
        customer_title = request.POST.get("customer_title")

        # Save data to database
        obj = customer_models.Customer(
            customer_name=customer_name, 
            customer_email=customer_email, 
            customer_password=customer_password,
            customer_phone=customer_phone,
            customer_title=customer_title
        )
        obj.save()

        # return HTML Page
        return HttpResponseRedirect("/admin/customers/view")
        
    return render(request, 'admin_module/customers_add.html')