from django.apps import AppConfig


class AdminModuleConfig(AppConfig):
    name = 'admin_module'
